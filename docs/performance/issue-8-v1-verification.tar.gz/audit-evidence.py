import csv, hashlib, json, math, pathlib, sys, xml.etree.ElementTree as ET
repository = pathlib.Path('/home/ubuntu/IdeaProjects/magika')
evidence = pathlib.Path('/tmp/magika-issue-8-evidence')
run = pathlib.Path(sys.argv[1])

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def distribution(values):
    values = sorted(values)
    return dict(samples=len(values), meanNs=sum(values)/len(values), minNs=values[0],
                p50Ns=values[math.ceil(len(values)*.50)-1], p95Ns=values[math.ceil(len(values)*.95)-1],
                p99Ns=values[math.ceil(len(values)*.99)-1], maxNs=values[-1])

def rows(path):
    with path.open() as source:
        return list(csv.DictReader(source))

sdk_digest = digest(repository/'target/magika-0.1.0.jar')
audit = {'sdkSha256': sdk_digest, 'matrix': {}, 'performance': {}}
for version in (8,17,21):
    entry = {}
    for kind in ('surefire', 'failsafe'):
        counts = dict.fromkeys(('tests', 'failures', 'errors', 'skipped'), 0)
        versions, homes = set(), set()
        reports = list((evidence/f'java-{version}'/f'{kind}-reports').glob('TEST-*.xml'))
        assert reports
        for report in reports:
            root = ET.parse(report).getroot()
            for key in counts:
                counts[key] += int(root.attrib[key])
            props = {x.attrib['name']:x.attrib['value'] for x in root.findall('./properties/property')}
            versions.add(props['java.runtime.version'])
            homes.add(props['java.home'])
        assert counts['tests'] == (39 if kind == 'surefire' else 17)
        assert not (counts['failures'] or counts['errors'] or counts['skipped'])
        entry[kind] = dict(counts, runtimeVersions=sorted(versions), javaHomes=sorted(homes))
    assert 'BUILD SUCCESS' in (evidence/f'java-{version}.log').read_text()
    assert (evidence/f'java-{version}'/'sdk.sha256').read_text().startswith(sdk_digest)
    offline = (evidence/f'offline-{version}.log').read_text()
    assert 'Shared instance' in offline and 'delivered=4' in offline
    audit['matrix'][str(version)] = entry
for scenario in ('path', 'stream', 'batch', 'shared'):
    source = run/scenario
    metadata = json.loads((source/'metadata.json').read_text())
    summary = json.loads((source/'summary.json').read_text())
    config = metadata['configuration']
    assert metadata['sdkJarSha256'] == sdk_digest
    all_rounds = rows(source/'rounds.csv')
    measured = [r for r in all_rounds if r['phase']=='measured']
    assert len(measured) == config['measurementRounds'] == 10
    assert len(all_rounds)-len(measured) == config['warmupRounds'] == 5
    assert config['itemsPerRound'] == 690
    for r in all_rounds:
        assert (int(r['items']),int(r['model_results']),int(r['rule_results']),int(r['failures'])) == (690,680,10,0)
    timings = rows(source/'latencies.csv')
    assert len(timings)==6900 and len({(r['round'],r['item']) for r in timings})==6900
    assert {int(r['round']) for r in timings} == set(range(10))
    assert {int(r['item']) for r in timings} == set(range(690))
    latencies = [int(r['latency_ns']) for r in timings]
    assert min(latencies)>0
    assert summary['items']==6900 and summary['modelResults']==6800 and summary['ruleResults']==100 and summary['failures']==0
    wall = sum(int(r['wall_ns']) for r in measured)
    assert summary['totalMeasuredWallNs']==wall
    assert math.isclose(summary['throughputItemsPerSecond'],6900/(wall/1e9),rel_tol=1e-12)
    expected = distribution(latencies)
    actual = summary['itemDeliveryLatency' if scenario=='batch' else 'requestLatency']
    assert expected==actual, (expected,actual)
    assert distribution([int(r['wall_ns']) for r in measured]) == summary['batchCallLatency' if scenario=='batch' else 'roundWallTime']
    memory = rows(source/'resources.csv')
    assert len(memory)==18 and memory[-1]['stage']=='after_sdk_close'
    audit['performance'][scenario] = summary
resource = rows(run/'resources'/'resources.csv')
assert len(resource)==19 and int(resource[-1]['completed_units'])==230
assert all(int(row['heap_used_bytes'])<=int(row['heap_committed_bytes'])<=int(row['heap_max_bytes']) for row in resource)
assert digest(repository/'src/test/resources/reference/path-manifest.json') == metadata['corpusManifestSha256']
for name, expected in json.loads((evidence/'tested-sources.json').read_text()).items():
    assert digest(repository/name)==expected, name
for name, expected in json.loads((evidence/'protected-before.json').read_text()).items():
    assert digest(repository/name)==expected, name
(evidence/'audit-summary.json').write_text(json.dumps(audit,indent=2)+'\n')
print('Audited raw percentiles, weighted throughput, outcomes, resource samples, JVM matrix and source/protected hashes.')
