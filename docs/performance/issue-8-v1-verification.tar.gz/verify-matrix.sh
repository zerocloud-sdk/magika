#!/usr/bin/env bash
set -euo pipefail
cd /home/ubuntu/IdeaProjects/magika
export JAVA_HOME=/usr/lib/jvm/java-21-openjdk-amd64
receipt=/tmp/magika-issue-8-evidence
for runtime in 8 17 21; do
  mkdir -p "$receipt/java-$runtime"
  status=0
  mvn -B -ntp -Dtest.java.home="/usr/lib/jvm/java-$runtime-openjdk-amd64" clean install > "$receipt/java-$runtime.log" 2>&1 || status=$?
  cp -R target/surefire-reports target/failsafe-reports "$receipt/java-$runtime/"
  sha256sum target/magika-0.1.0.jar > "$receipt/java-$runtime/sdk.sha256"
  test "$status" -eq 0 || exit "$status"
  echo "Java $runtime full build passed"
done
mvn -B -ntp -f examples/offline/pom.xml clean package > "$receipt/consumer-build.log" 2>&1
for runtime in 8 17 21; do
  bash scripts/verify-offline.sh "/usr/lib/jvm/java-$runtime-openjdk-amd64" > "$receipt/offline-$runtime.log" 2>&1
  echo "Java $runtime offline consumer passed"
done
