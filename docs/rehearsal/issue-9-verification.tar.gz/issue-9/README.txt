Issue #9 signed candidate evidence
Source: 5f74b9884329703cce5b888408fc741d1ba8d444
Rehearsal: https://github.com/zerocloud-sdk/magika/actions/runs/35283223620
Regular CI: https://github.com/zerocloud-sdk/magika/actions/runs/35283191076

The candidate directory intentionally stores one copy of the signed bundle.
Unzip candidate/central-bundle.zip into a temporary directory, then copy
net/zerocloud/magika/0.1.0/* back into candidate/. All original distribution
files, signatures and checksum files are in the ZIP. candidate.json and
signer.asc stay alongside them. Run the verifier from a checkout of the
source SHA, with MAVEN_GPG_FINGERPRINT=C5149FD6B5EF7C2126F1FD0FCC1A12E348E171D8.

java-*/ contains original CI XML, runtime/build/offline logs and signed
consumer logs. summary.json derives counts from the XML; it does not
infer test success only from the workflow conclusion.
No Central upload, version tag, GitHub Release, or release-ledger write
was performed. All signing material in this archive is public.
