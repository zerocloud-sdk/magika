import hashlib, json, pathlib, re, shutil, subprocess, xml.etree.ElementTree as ET

repo = pathlib.Path('/home/ubuntu/IdeaProjects/magika')
work = pathlib.Path('/tmp/magika-issue10')
remote = work/'remote'
out = work/'delivery/issue-10'
source = (work/'release-source-sha.txt').read_text().strip()
load = lambda p: json.loads(p.read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
def write(p, value):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(value if isinstance(value, str) else json.dumps(value, indent=2)+'\n')
def copy(a,b):
    b.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(a,b)

run = load(work/'release-run.json')
assert run['headSha']==source and run['status']=='completed' and run['conclusion']=='success'
first=load(work/'release-attempt-1.json')
assert len(first['jobs'])==9 and all(j['conclusion']=='success' for j in first['jobs'] if j['name']!='publish')
assert next(j for j in first['jobs'] if j['name']=='publish')['conclusion']=='failure'
assert len(run['jobs'])==9 and all(j['conclusion']=='success' for j in run['jobs'])
assert load(work/'release-api.json')['run_attempt']==2
candidate = load(remote/'signed-candidate/candidate.json')
assert candidate['sourceSha']==source and candidate['coordinate']=='net.zerocloud:magika:0.1.0'
external = load(work/'external-state.json')
assert external['published'] is True and external['status']['deploymentState']=='PUBLISHED'
assert external['record']['state']['phase']=='complete'
assert external['record']['state']['candidate']==candidate
assert external['tag']['object']['sha']==source
assert external['release']['target_commitish']==source
assert external['publicFiles']=='complete'
assert sha((remote/'signed-candidate/central-bundle.zip').read_bytes())==candidate['bundleSha256']
assert candidate['model']=='standard_v3_3' and candidate['upstreamCommit']=='9f225aa480e675af44343b9160f077073ed1b752'
assert {a['file']:a['sha256'] for a in candidate['assets']}=={
    'model.onnx':'fe2d2eb49c5f88a9e0a6c048e15d6ffdf86235519c2afc535044de433169ec8c',
    'config.min.json':'ae24c742205358f6ff6dfd5facb6743fb69743dbba8373e73da58ff0cbd695db',
    'content_types_kb.min.json':'75208adba69bc0556403b62b32ef3ccf8b5ce494411780845852e52e6583a10d'}
sdk_hash=candidate['artifacts']['magika-0.1.0.jar']['sha256']
assert not out.exists()
out.mkdir(parents=True)
matrix=[]
for runtime in ('8','17','21'):
    unsigned=load(remote/f'candidate-java-{runtime}/candidate.json')
    for k in unsigned: assert unsigned[k]==candidate[k],k
    base=remote/f'verification-java-{runtime}'
    summary={'runtime':runtime,'surefire':dict.fromkeys(('tests','failures','errors','skipped'),0),
             'failsafe':dict.fromkeys(('tests','failures','errors','skipped'),0),'testCases':[]}
    versions=set(); vendors=set()
    for file in base.rglob('*'):
        if not file.is_file(): continue
        kind='surefire' if 'surefire-reports' in file.parts else 'failsafe' if 'failsafe-reports' in file.parts else None
        copy(file,out/f'java-{runtime}'/(kind or 'logs')/file.name)
        if kind and file.name.startswith('TEST-') and file.suffix=='.xml':
            suite=ET.parse(file).getroot()
            for k in summary[kind]:summary[kind][k]+=int(suite.get(k))
            props={p.get('name'):p.get('value') for p in suite.findall('./properties/property')}
            versions.add(props['java.runtime.version']); vendors.add(props['java.vendor'])
            for test in suite.findall('testcase'):
                assert not any(test.find(x) is not None for x in ('skipped','failure','error'))
                summary['testCases'].append(test.get('classname')+'.'+test.get('name'))
    assert summary['surefire']=={'tests':39,'failures':0,'errors':0,'skipped':0}
    assert summary['failsafe']=={'tests':17,'failures':0,'errors':0,'skipped':0}
    assert len(versions)==len(vendors)==1
    summary['javaRuntimeVersion']=versions.pop();summary['javaVendor']=vendors.pop()
    assert summary['javaRuntimeVersion'].startswith('1.8.' if runtime=='8' else runtime+'.')
    log=(out/f'java-{runtime}/logs/maven.log').read_text()
    environment=(out/f'java-{runtime}/logs/runtime.log').read_text()
    assert environment.splitlines()[0]==source and 'Temurin-21.0.12.1+1' in environment
    assert 'Ubuntu 24.04' in environment and 'x86_64' in environment
    assert 'Exact feature references: 9261' in log
    assert 'All content references (byte[] and stream): 141' in log
    assert 'All path references (Path, byte[] and stream): 207' in log
    errors=[float(x) for x in re.findall(r'max absolute score error=([\d.Ee+-]+)',log)]
    assert errors and all(x<=1e-5 for x in errors)
    summary['referenceMaxScoreErrors']=errors
    assert 'inputs=1000003' in log and 'delivered=1000003' in log
    assert 'bytes=2147483665' in log
    expected=['all9261OfficialFeaturesMatchExactly','all141ContentsMatchThroughPublicApiInEveryMode',
              'all207PathsMatchReferencesAndCompleteBytesInEveryMode','generatedStreamLargerThanHeapAndIntRangeUsesBoundedSampling',
              'millionLazyPathsFitInLimitedHeapWithoutRetainingResults','realSharedSessionAndNativeLifecycleFailures']
    for method in expected: assert any(x.endswith('.'+method) for x in summary['testCases']),method
    signed=remote/f'signed-consumer-java-{runtime}/signed-consumer.log'
    signed_text=signed.read_text()
    for text in [f'SDK origin=/app/magika-0.1.0.jar; SHA-256={sdk_hash}',
                 'Isolation verified: no external network interface; Java-only root and PATH',
                 '"signaturesVerified":4','Batch delivered=4, successful=3, fileFailures=1',
                 'Shared instance: 16 requests','BEST_GUESS:']:
        assert text in signed_text,text
    copy(signed,out/f'java-{runtime}/signed-consumer.log')
    matrix.append(summary)

tool_log=(out/'java-21/logs/release-tests.log').read_text()
assert re.search(r'tests 28\b',tool_log) and re.search(r'fail 0\b',tool_log) and re.search(r'skipped 0\b',tool_log)
consumers=[]
for runtime in ('8','17','21'):
    base=work/f'central-java-{runtime}'
    receipt=load(base/'central-downloads.json')
    assert receipt['sourceSha']==source and receipt['sdkSha256']==sdk_hash and receipt['candidateInstalled'] is False
    assert len(receipt['downloads'])==8
    for item in receipt['downloads']:
        name=item['url'].rsplit('/',1)[1]
        assert item['url']=='https://repo.maven.apache.org/maven2/net/zerocloud/magika/0.1.0/'+name
        assert item['status']==200 and item['sha256']=={**candidate['artifacts'],**candidate['signatures']}[name]['sha256']
        assert sha((base/'central-files'/name).read_bytes())==item['sha256']
    for phase in ('online','offline'):
        text=(base/f'java-only-{phase}.log').read_text()
        for required in [f'SDK origin=/app/magika-0.1.0.jar; SHA-256={sdk_hash}',
                         'Isolation verified: Java-only root and PATH; no Python',
                         'pdf application/pdf score=','Saved upload:','Stream upload from current position to EOF:',
                         'Batch delivered=4, successful=3, fileFailures=1','Batch aborted: stage=CALLBACK, delivered=2',
                         'Shared instance: 16 requests','HIGH_CONFIDENCE:','MEDIUM_CONFIDENCE:','BEST_GUESS:']:
            assert required in text,required
        if phase=='offline':assert 'Isolation verified: no external network interface' in text
        assert 'BUILD SUCCESS' in (base/f'maven-{phase}.log').read_text()
    for name in ('central-downloads.json','runtime.log','maven-online.log','maven-offline.log',
                 'java-only-online.log','java-only-offline.log','settings.xml'):
        copy(base/name,out/f'central-java-{runtime}'/name)
    copy(base/'repository/net/zerocloud/magika/0.1.0/_remote.repositories',out/f'central-java-{runtime}/sdk-cache-origin.txt')
    shutil.copytree(base/'consumer/src',out/f'central-java-{runtime}/consumer/src')
    copy(base/'consumer/pom.xml',out/f'central-java-{runtime}/consumer/pom.xml')
    jars={p.name:sha(p.read_bytes()) for p in (base/'consumer/target/dependency').glob('*.jar')}
    assert jars['magika-0.1.0.jar']==sdk_hash
    for line in (repo/'docs/performance/issue-8-v1/artifacts.sha256').read_text().splitlines():
        expected,p=line.split(None,1); name=pathlib.Path(p).name
        if name in jars and not name.startswith('magika-'):assert jars[name]==expected
    receipt['runtime']=(base/'runtime.log').read_text().strip()
    receipt['dependencies']=jars
    receipt['javaOnlyOnlinePassed']=receipt['offlineMavenPassed']=receipt['javaOnlyOfflinePassed']=True
    consumers.append(receipt)

for name in ('candidate.json','central-bundle.zip','signer.asc','SHA256SUMS'):
    copy(remote/'signed-candidate'/name,out/'candidate'/name)
shutil.copytree(work/'central-java-8/central-files',out/'central-downloaded-files')
copy(repo/'benchmarks/target/dependency/magika-0.1.0.jar',out/'performance/measured-magika-0.1.0.jar')
performance=load(work/'performance-equivalence.json')
assert performance['releaseSdkSha256']==sdk_hash and performance['identicalClassCount']==27
for name in ('release-run.json','external-state.json','preflight.json','performance-equivalence.json',
             'review-preparation-standards.md','review-preparation-spec.md','preparation.patch',
             'local-build.log','release-tests.log','preparation-java-only-online.log','preparation-java-only-offline.log',
             'commands.txt','build-evidence.py','consumer-environment.txt','source-lineage.txt',
             'production-and-test-diff.txt','release-attempt-1.json','release-attempt-1.log',
             'publish-failure-state.json','deployment-observations.jsonl','public-observations.jsonl',
             'recovery-preflight.json','release-api.json','raw-matrix-audit.json',
             'local-release-signature-verification.json'):
    copy(work/name,out/name)
shutil.copytree(work/'diagnosis',out/'diagnosis')
copy(remote/'signature-verification/signature-verification.log',out/'signature-verification.log')
copy(work/'release-full.log',out/'release-full.log')
protected=load(work/'untracked-before.json')
untracked=set(subprocess.check_output(['git','ls-files','--others','--exclude-standard','-z'],cwd=repo).decode().split('\0'))
for p,h in protected.items():
    assert p in untracked and sha((repo/p).read_bytes())==h
summary={'schema':1,'fixedReviewBase':'65cb8714f42be2632548c2a28513371b070baf5a','releaseSourceSha':source,
         'coordinate':candidate['coordinate'],'model':candidate['model'],'upstreamCommit':candidate['upstreamCommit'],
         'assets':candidate['assets'],'releaseRun':run['url'],'releaseRunId':run['databaseId'],
         'releaseAttempts':{'initial':first,'final':run},
         'centralState':'PUBLISHED','deploymentId':external['status']['deploymentId'],
         'tag':external['tag']['ref'],'githubRelease':external['release']['html_url'],
         'ledgerCommit':external['ledgerRef']['object']['sha'], 'candidate':candidate,
         'matrix':matrix,'centralConsumers':consumers,'performanceEquivalence':performance,
         'releaseToolTests':{'tests':28,'failures':0,'skipped':0},
         'originalUntrackedFiles':{'count':len(protected),'unchanged':True,'remainUntracked':True},
         'historicalLimitation':'Issue #6 descriptor assertion root cause remains unknown; subsequent passes are not a demonstrated fix.'}
write(out/'summary.json',summary)
write(work/'summary.json',summary)
print(json.dumps({'source':source,'matrix':[(x['runtime'],x['surefire'],x['failsafe']) for x in matrix],
                  'centralConsumers':len(consumers),'deploymentId':summary['deploymentId'],'files':sum(p.is_file() for p in out.rglob('*'))},indent=2))
